-- Once installed the .exe file must be run in administrator mode to write to files.

To do this:

1. Navigate to where the program is installed
2. Right click on SongBookApp.exe
3. Click properties
4. Click compatibility tab
5. Check the run as administrator box
6. Click ok and apply

Now every time the exe is run it will be in administrator mode
